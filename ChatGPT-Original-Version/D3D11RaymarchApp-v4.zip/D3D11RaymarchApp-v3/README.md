# D3D11 Raymarch Application

这是原 WebGL 程序的 Windows / Direct3D 11 原生版本。

## 渲染与交互

- Direct3D 11 Pixel Shader 执行原来的 Raymarching / fractal 计算
- 自动旋转：每帧 `ang1 += 0.01`
- 鼠标左键拖拽：旋转
- 鼠标右键拖拽：平移
- 鼠标滚轮：缩放
- Windows 触摸：单指旋转、双指平移 + 捏合缩放
- 窗口客户区中的实际渲染区域保持正方形

主窗口只有 Win32 HWND + Direct3D 11 渲染链，不创建 GDI 子控件，也不使用 Direct2D 叠加层。

## Kernel 编辑器

主窗口系统菜单底部会追加一个分隔线和 `&Kernel...`。

点击 `Kernel...` 后，程序创建一个**独立、可调整大小、可最大化、支持 DPI 切换**的 Win32 编辑窗口，其中包含：

- 多行 `EDIT` 控件
- `Apply` 按钮
- `Cancel` 按钮

Kernel 在程序内部以 LF（`\n`）作为规范形式，而 Win32 多行 `EDIT` 在显示时使用 CRLF（`\r\n`）。打开编辑器时会把 LF 转换成 CRLF；点击 `Apply` 时再转换回 LF，因此初始 Kernel 不会被压成一行。

`Apply` 会即时重新编译 Pixel Shader。只有 Shader 编译成功时，新的 Kernel 才会替换当前 Shader；失败时继续使用当前 Shader。

## DPI / Visual Styles

源码通过 linker pragma 嵌入 `D3D11RaymarchApp.manifest`。Manifest：

- 启用 `Microsoft.Windows.Common-Controls` v6，使标准 Win32 EDIT/BUTTON 使用现代视觉样式
- 声明 PerMonitorV2 DPI 感知
- 声明 Windows 8.1 / Windows 10+ compatibility

进程启动时还显式调用 `SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2)`；主窗口和 Kernel 编辑窗口都会处理 `WM_DPICHANGED`。Kernel 窗口中的字体、按钮、边距和最小尺寸按当前 DPI 缩放。

## 构建

需要 Visual Studio / MSVC（含 Desktop development with C++）和 Windows SDK。

直接使用 MSVC：

```bat
cl /EHsc /utf-8 /D_UNICODE /DUNICODE /std:c++20 main.cpp user32.lib winmm.lib
```

`main.cpp` 会通过：

```cpp
#pragma comment(linker, "/manifest:embed")
#pragma comment(linker, "/manifestinput:D3D11RaymarchApp.manifest")
```

将同目录的 manifest 嵌入最终 EXE，因此不需要手工运行 `mt.exe`。

CMake：

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
```

`kernel.glsl` 会在构建后复制到 exe 同目录。启动时如果找到它，会优先从文件加载；找不到时程序使用内置默认 Kernel。
