# D3D11 Raymarch Application

这是原 WebGL 程序的 Windows / Direct3D 11 原生版本。

## 渲染与交互

- Direct3D 11 Pixel Shader 执行原来的 Raymarching / fractal 计算
- 自动旋转：每帧 `ang1 += 0.01`
- 鼠标左键拖拽：旋转
- 鼠标右键拖拽：平移
- 鼠标滚轮：缩放
- Windows 触摸：单指旋转、双指平移 + 捏合缩放
- 窗口客户区中的实际渲染区域保持正方形

主 D3D11 窗口不创建 GDI 子控件，也不使用 Direct2D 叠加 UI。

## Kernel 编辑器

主窗口系统菜单底部会追加一个分隔线和 `&Kernel...`。

点击 `Kernel...` 后，程序创建一个独立的 GDI 编辑窗口，其中包含：

- 多行 `EDIT` 控件
- `Apply` 按钮
- `Cancel` 按钮

`Apply` 会即时重新编译 Pixel Shader。只有 Shader 编译并创建成功时，新的 Kernel 才会替换当前 Kernel；编译失败时会保留当前正在使用的 Shader。

编辑器接受原程序使用的 GLSL 风格 Kernel，例如：

```glsl
float kernal(vec3 ver){
    return 4.0 - dot(ver, ver);
}
```

程序会在运行时做一层轻量 GLSL → HLSL 转换，然后使用 Windows SDK 的 `D3DCompile` 编译 `ps_5_0`。

当前转换器针对这个程序的原始 Kernel 和常见数学表达式处理：

- `vec2/vec3/vec4` → `float2/float3/float4`
- `atan(y,x)` → `atan2(y,x)`
- `mix` → `lerp`
- `fract` → `frac`
- 去除 GLSL precision 声明

## 构建

需要 Visual Studio / MSVC（含 Desktop development with C++）和 Windows SDK。

直接使用 MSVC：

```bat
cl /EHsc /utf-8 /D_UNICODE /DUNICODE /std:c++20 main.cpp user32.lib winmm.lib
```

CMake：

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
```

`kernel.glsl` 会在构建后复制到 exe 同目录。启动时如果找到它，会优先从文件加载；找不到时程序使用内置默认 Kernel。

## 说明

主窗口现在只有 Win32 窗口 + Direct3D 11 渲染链；Kernel 编辑窗口单独存在，因此编辑器的 GDI 控件不会覆盖或参与 D3D11 主窗口的客户区。
