# D3D11 Raymarch Application

这是原 WebGL 程序的 Windows / Direct3D 11 原生版本。

## 功能

- Direct3D 11 实时渲染原来的三维 Julia/分形效果
- 自动旋转，速度与原程序相同：每帧 `ang1 += 0.01`
- 鼠标左键拖拽：旋转
- 鼠标右键拖拽：平移
- 鼠标滚轮：缩放
- Windows 触摸：单指旋转、双指平移 + 捏合缩放
- `CONFIG` / `HIDE`：显示或隐藏 Kernel 编辑器
- 工具栏按钮使用 Direct2D 绘制，不创建 GDI BUTTON 子窗口
- `APPLY`：即时重新编译 Pixel Shader
- `CANCEL`：恢复编辑框中的 Kernel
- 窗口可以自由缩放，渲染区域保持正方形

## 构建

需要 Visual Studio / MSVC（含 Desktop development with C++）和 Windows SDK。

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
```

生成的程序位于：

```text
build/Release/D3D11RaymarchApp.exe
```

`kernel.glsl` 会在构建后复制到 exe 同目录。启动时如果找到它，会优先从文件加载；找不到时程序使用内置默认 Kernel。

## Kernel 编辑

编辑器仍然接受原程序使用的 GLSL 风格 Kernel，例如：

```glsl
float kernal(vec3 ver){
    return 4.0 - dot(ver, ver);
}
```

程序会在运行时做一层轻量 GLSL → HLSL 转换，然后用 Windows SDK 的 `D3DCompile` 编译 Shader。

当前转换器针对这个程序原来的 Kernel 以及常见数学表达式进行了兼容处理，例如：

- `vec2/vec3/vec4` → `float2/float3/float4`
- `atan(y,x)` → `atan2(y,x)`
- `mix` → `lerp`
- `fract` → `frac`
- 去除 GLSL precision 声明

因此原来的 Kernel 可以直接使用。若后续加入大量 GLSL 特有语法（纹理采样、矩阵构造、GLSL 专有扩展等），需要继续扩充转换器。
